import { saveProfile, getAllProfiles, deleteProfile } from './storage.js';
import { generateId, imageFileToBase64 } from './utils.js';

const root = document.getElementById('app-root');
document.getElementById('show-admin').onclick = showAdmin;
document.getElementById('show-form').onclick = showForm;

// Check for profile data in URL
window.addEventListener('DOMContentLoaded', () => {
  const urlParams = new URLSearchParams(window.location.search);
  const profileData = urlParams.get('profile');
  const formShare = urlParams.get('form');
  
  if (profileData) {
    try {
      const decodedData = JSON.parse(atob(profileData));
      prefillForm(decodedData);
    } catch (error) {
      console.error('Error parsing profile data:', error);
    }
  } else if (formShare === 'share') {
    // Show the form for shared access
    showForm();
  }
});

function showForm() {
  root.innerHTML = `
    <h2>Add / Fill Profile</h2>
    <div class="form-header">
      <button id="share-form-link" class="share-form-btn">📤 Share Form Link</button>
    </div>
    <form id="profile-form">
      <input type="text" name="name" placeholder="Full Name" required>
      <input type="number" name="age" placeholder="Age" required>
      <input type="text" name="education" placeholder="Education">
      <input type="text" name="profession" placeholder="Profession">
      <input type="text" name="location" placeholder="Location">
      <textarea name="about" placeholder="About person"></textarea>
      <label>Photo:</label>
      <input type="file" id="photo" accept="image/*">
      <button type="submit">Save</button>
    </form>
  `;

  const form = document.getElementById('profile-form');
  form.onsubmit = async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    let photoData = null;
    const file = document.getElementById('photo').files[0];
    if (file) photoData = await imageFileToBase64(file);
    const profile = {
      id: generateId(),
      ...data,
      photo: photoData,
      createdAt: new Date().toISOString()
    };
    await saveProfile(profile);
    alert('Profile saved!');
    showAdmin();
  };

  // Add event listener for share form link
  document.getElementById('share-form-link').onclick = () => {
    showShareFormModal();
  };
}

function prefillForm(profileData) {
  // Show the form with pre-filled data
  showForm();
  
  // Wait for form to be rendered, then fill the fields
  setTimeout(() => {
    const form = document.getElementById('profile-form');
    if (form) {
      // Fill text fields
      if (profileData.name) form.querySelector('[name="name"]').value = profileData.name;
      if (profileData.age) form.querySelector('[name="age"]').value = profileData.age;
      if (profileData.education) form.querySelector('[name="education"]').value = profileData.education;
      if (profileData.profession) form.querySelector('[name="profession"]').value = profileData.profession;
      if (profileData.location) form.querySelector('[name="location"]').value = profileData.location;
      if (profileData.about) form.querySelector('[name="about"]').value = profileData.about;
      
      // Handle photo if available
      if (profileData.photo) {
        // Create a data URL from base64
        const img = document.createElement('img');
        img.src = profileData.photo;
        img.style.maxWidth = '200px';
        img.style.marginTop = '10px';
        
        const photoLabel = form.querySelector('label[for="photo"]');
        if (photoLabel) {
          photoLabel.parentNode.insertBefore(img, photoLabel.nextSibling);
        }
      }
      
      // Show success message
      alert('Profile data loaded! You can edit and save the form.');
    }
  }, 100);
}

function showShareFormModal() {
  // Create a shareable form link
  const formUrl = `${window.location.origin}${window.location.pathname}?form=share`;
  
  root.innerHTML = `
    <div class="share-form-modal">
      <div class="share-form-content">
        <h2>📤 Share Form Link</h2>
        <p>Share this link with others to let them fill out the profile form on their own devices:</p>
        
        <div class="share-link-container">
          <label>Shareable Form Link:</label>
          <div class="link-input-container">
            <input type="text" id="form-share-link" value="${formUrl}" readonly>
            <button id="copy-form-link" class="copy-btn">Copy</button>
          </div>
        </div>
        
        <div class="share-options">
          <button id="share-whatsapp" class="whatsapp-share-btn">📱 Share via WhatsApp</button>
          <button id="share-email" class="email-share-btn">📧 Share via Email</button>
          <button id="share-copy" class="copy-share-btn">📋 Copy Link</button>
        </div>
        
        <div class="form-info">
          <h3>How it works:</h3>
          <ul>
            <li>✅ Share the link with anyone</li>
            <li>✅ They can fill the form on any device</li>
            <li>✅ Profile automatically appears in your admin panel</li>
            <li>✅ No registration required</li>
          </ul>
        </div>
        
        <div class="modal-actions">
          <button id="close-share-modal" class="close-btn">Close</button>
        </div>
      </div>
    </div>
  `;
  
  // Add event listeners
  document.getElementById('copy-form-link').onclick = () => {
    const linkInput = document.getElementById('form-share-link');
    linkInput.select();
    document.execCommand('copy');
    alert('Form link copied to clipboard!');
  };
  
  document.getElementById('share-whatsapp').onclick = () => {
    const message = `📝 *Marriage Bureau Profile Form*

Fill out this form to add your profile:

${formUrl}

_Shared from Marriage Bureau App_`;
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };
  
  document.getElementById('share-email').onclick = () => {
    const subject = 'Marriage Bureau Profile Form';
    const body = `Hello!

Please fill out this form to add your profile to our Marriage Bureau:

${formUrl}

Thank you!`;
    const mailtoUrl = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(mailtoUrl, '_blank');
  };
  
  document.getElementById('share-copy').onclick = () => {
    const linkInput = document.getElementById('form-share-link');
    linkInput.select();
    document.execCommand('copy');
    alert('Form link copied to clipboard!');
  };
  
  document.getElementById('close-share-modal').onclick = () => {
    showForm();
  };
}

function editProfile(profile) {
  // Show the form with pre-filled data for editing
  root.innerHTML = `
    <h2>Edit Profile</h2>
    <form id="profile-form">
      <input type="text" name="name" placeholder="Full Name" value="${profile.name || ''}" required>
      <input type="number" name="age" placeholder="Age" value="${profile.age || ''}" required>
      <input type="text" name="education" placeholder="Education" value="${profile.education || ''}">
      <input type="text" name="profession" placeholder="Profession" value="${profile.profession || ''}">
      <input type="text" name="location" placeholder="Location" value="${profile.location || ''}">
      <textarea name="about" placeholder="About person">${profile.about || ''}</textarea>
      <label>Photo:</label>
      ${profile.photo ? `<div class="current-photo"><img src="${profile.photo}" alt="Current photo" style="max-width: 200px; margin: 10px 0;"><p>Current photo</p></div>` : ''}
      <input type="file" id="photo" accept="image/*">
      <div class="form-actions">
        <button type="submit">Update Profile</button>
        <button type="button" id="cancel-edit">Cancel</button>
      </div>
    </form>
  `;

  const form = document.getElementById('profile-form');
  form.onsubmit = async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    let photoData = profile.photo; // Keep existing photo by default
    
    const file = document.getElementById('photo').files[0];
    if (file) {
      photoData = await imageFileToBase64(file);
    }
    
    const updatedProfile = {
      id: profile.id, // Keep the same ID
      ...data,
      photo: photoData,
      createdAt: profile.createdAt, // Keep original creation date
      updatedAt: new Date().toISOString() // Add update timestamp
    };
    
    await saveProfile(updatedProfile);
    alert('Profile updated successfully!');
    showAdmin();
  };

  document.getElementById('cancel-edit').onclick = () => {
    showAdmin();
  };
}

async function showAdmin() {
  const profiles = await getAllProfiles();
  root.innerHTML = '<h2>Saved Profiles</h2>';
  if (!profiles.length) {
    root.innerHTML += '<p>No profiles found.</p>';
    return;
  }
  
  const container = document.createElement('div');
  container.className = 'card-container';
  
  profiles.forEach(p => {
    const div = document.createElement('div');
    div.className = 'card';
    div.innerHTML = `
      ${p.photo ? `<img src="${p.photo}" alt="photo">` : '<div class="no-image">📷 No Photo</div>'}
      <h3>${p.name || 'No Name'}, ${p.age || 'No Age'}</h3>
      <p><strong>Education:</strong> ${p.education || 'Not specified'}</p>
      <p><strong>Profession:</strong> ${p.profession || 'Not specified'}</p>
      <p><strong>Location:</strong> ${p.location || 'Not specified'}</p>
      <p>${p.about || 'No additional information'}</p>
      <div class="card-actions">
        <button data-id="${p.id}" class="delete-btn">Delete</button>
        <button data-id="${p.id}" class="share-btn">Share</button>
        <button data-id="${p.id}" class="edit-btn">Edit</button>
      </div>
    `;
    container.appendChild(div);
  });
  
  root.appendChild(container);

  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.onclick = async () => {
      await deleteProfile(btn.dataset.id);
      alert('Profile deleted');
      showAdmin();
    };
  });

  document.querySelectorAll('.share-btn').forEach(btn => {
    btn.onclick = () => {
      const profile = profiles.find(p => p.id === btn.dataset.id);
      if (profile) {
        shareToWhatsApp(profile);
      }
    };
  });

  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.onclick = () => {
      const profile = profiles.find(p => p.id === btn.dataset.id);
      if (profile) {
        editProfile(profile);
      }
    };
  });
}

function shareToWhatsApp(profile) {
  // Create a simple text message
  let message = `💍 *Marriage Bureau Profile*

👤 *${profile.name || 'No Name'}*, ${profile.age || 'No Age'} years old`;

  // Add education if available
  if (profile.education && profile.education.trim()) {
    message += `\n🎓 *Education:* ${profile.education}`;
  }

  // Add profession if available
  if (profile.profession && profile.profession.trim()) {
    message += `\n💼 *Profession:* ${profile.profession}`;
  }

  // Add location if available
  if (profile.location && profile.location.trim()) {
    message += `\n📍 *Location:* ${profile.location}`;
  }

  // Add about section if available
  if (profile.about && profile.about.trim()) {
    message += `\n\n📝 *About:*\n${profile.about}`;
  }

  message += `\n\n_Shared from Marriage Bureau App_`;

  // Check if Web Share API is supported (for mobile devices)
  if (navigator.share) {
    shareWithNativeAPI(profile, message);
  } else {
    // Fallback for desktop - create image and open WhatsApp
    if (profile.photo) {
      createProfileImage(profile, message);
    } else {
      // Just share the text message
      const encodedMessage = encodeURIComponent(message);
      const whatsappUrl = `https://wa.me/?text=${encodedMessage}`;
      window.open(whatsappUrl, '_blank');
    }
  }
}

async function shareWithNativeAPI(profile, message) {
  try {
    if (profile.photo) {
      // Create the profile image first
      const imageBlob = await createProfileImageBlob(profile);
      
      // Create a file from the blob
      const file = new File([imageBlob], `${profile.name || 'profile'}_card.jpg`, {
        type: 'image/jpeg'
      });
      
      // Share with native API
      await navigator.share({
        title: 'Marriage Bureau Profile',
        text: message,
        files: [file]
      });
    } else {
      // Share just text
      await navigator.share({
        title: 'Marriage Bureau Profile',
        text: message
      });
    }
  } catch (error) {
    console.log('Native sharing failed, falling back to WhatsApp URL');
    // Fallback to WhatsApp URL method
    if (profile.photo) {
      createProfileImage(profile, message);
    } else {
      const encodedMessage = encodeURIComponent(message);
      const whatsappUrl = `https://wa.me/?text=${encodedMessage}`;
      window.open(whatsappUrl, '_blank');
    }
  }
}

function createProfileImage(profile, textMessage) {
  // Create a canvas to generate a combined image
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  // Set canvas size
  canvas.width = 400;
  canvas.height = 600;
  
  // Create image from base64
  const img = new Image();
  img.onload = function() {
    // Draw background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw border
    ctx.strokeStyle = '#b22222';
    ctx.lineWidth = 3;
    ctx.strokeRect(0, 0, canvas.width, canvas.height);
    
    // Draw photo (scaled to fit)
    const photoSize = 200;
    const photoX = (canvas.width - photoSize) / 2;
    const photoY = 20;
    ctx.drawImage(img, photoX, photoY, photoSize, photoSize);
    
    // Draw text
    ctx.fillStyle = '#333333';
    ctx.font = 'bold 20px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('💍 Marriage Bureau Profile', canvas.width/2, photoY + photoSize + 40);
    
    ctx.font = 'bold 16px Arial';
    ctx.fillText(`${profile.name || 'No Name'}, ${profile.age || 'No Age'}`, canvas.width/2, photoY + photoSize + 70);
    
    // Add other details
    let yPos = photoY + photoSize + 100;
    ctx.font = '14px Arial';
    ctx.textAlign = 'left';
    
    if (profile.education && profile.education.trim()) {
      ctx.fillText(`Education: ${profile.education}`, 20, yPos);
      yPos += 25;
    }
    
    if (profile.profession && profile.profession.trim()) {
      ctx.fillText(`Profession: ${profile.profession}`, 20, yPos);
      yPos += 25;
    }
    
    if (profile.location && profile.location.trim()) {
      ctx.fillText(`Location: ${profile.location}`, 20, yPos);
      yPos += 25;
    }
    
    if (profile.about && profile.about.trim()) {
      ctx.fillText(`About: ${profile.about}`, 20, yPos);
    }
    
    // Convert canvas to image and share
    canvas.toBlob(function(blob) {
      // Create download link
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${profile.name || 'profile'}_card.jpg`;
      link.style.display = 'none';
      document.body.appendChild(link);
      
      // Show instructions
      alert(`Profile card image created!\n\nTo share:\n1. The image will download automatically\n2. Open WhatsApp and send the downloaded image\n3. Copy and paste this text with the image:\n\n${textMessage}`);
      
      // Download the image
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      // Also open WhatsApp with text
      const encodedMessage = encodeURIComponent(textMessage);
      const whatsappUrl = `https://wa.me/?text=${encodedMessage}`;
      window.open(whatsappUrl, '_blank');
    }, 'image/jpeg', 0.9);
  };
  
  img.src = profile.photo;
}

async function createProfileFromData(profileData) {
  try {
    // Create a new profile with the shared data
    const newProfile = {
      id: generateId(),
      name: profileData.name || '',
      age: profileData.age || '',
      education: profileData.education || '',
      profession: profileData.profession || '',
      location: profileData.location || '',
      about: profileData.about || '',
      photo: profileData.photo || null,
      createdAt: new Date().toISOString()
    };
    
    // Save the profile
    await saveProfile(newProfile);
    
    // Show success message and go to admin
    alert('Profile added successfully!');
    showAdmin();
  } catch (error) {
    console.error('Error creating profile:', error);
    alert('Error adding profile. Please try again.');
  }
}

function createProfileImageBlob(profile) {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    // Set canvas size
    canvas.width = 400;
    canvas.height = 600;
    
    // Create image from base64
    const img = new Image();
    img.onload = function() {
      // Draw background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Draw border
      ctx.strokeStyle = '#b22222';
      ctx.lineWidth = 3;
      ctx.strokeRect(0, 0, canvas.width, canvas.height);
      
      // Draw photo (scaled to fit)
      const photoSize = 200;
      const photoX = (canvas.width - photoSize) / 2;
      const photoY = 20;
      ctx.drawImage(img, photoX, photoY, photoSize, photoSize);
      
      // Draw text
      ctx.fillStyle = '#333333';
      ctx.font = 'bold 20px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('💍 Marriage Bureau Profile', canvas.width/2, photoY + photoSize + 40);
      
      ctx.font = 'bold 16px Arial';
      ctx.fillText(`${profile.name || 'No Name'}, ${profile.age || 'No Age'}`, canvas.width/2, photoY + photoSize + 70);
      
      // Add other details
      let yPos = photoY + photoSize + 100;
      ctx.font = '14px Arial';
      ctx.textAlign = 'left';
      
      if (profile.education && profile.education.trim()) {
        ctx.fillText(`Education: ${profile.education}`, 20, yPos);
        yPos += 25;
      }
      
      if (profile.profession && profile.profession.trim()) {
        ctx.fillText(`Profession: ${profile.profession}`, 20, yPos);
        yPos += 25;
      }
      
      if (profile.location && profile.location.trim()) {
        ctx.fillText(`Location: ${profile.location}`, 20, yPos);
        yPos += 25;
      }
      
      if (profile.about && profile.about.trim()) {
        ctx.fillText(`About: ${profile.about}`, 20, yPos);
      }
      
      // Convert canvas to blob
      canvas.toBlob(resolve, 'image/jpeg', 0.9);
    };
    
    img.onerror = reject;
    img.src = profile.photo;
  });
}

function showQRCode(profile) {
  // Create a shareable link with profile data
  const profileData = {
    name: profile.name,
    age: profile.age,
    education: profile.education,
    profession: profile.profession,
    location: profile.location,
    about: profile.about,
    photo: profile.photo
  };
  
  // Encode profile data as base64
  const encodedData = btoa(JSON.stringify(profileData));
  const shareUrl = `${window.location.origin}${window.location.pathname}?profile=${encodedData}`;
  
  // Create QR code modal
  root.innerHTML = `
    <div class="qr-modal">
      <div class="qr-content">
        <h2>📱 Share Profile</h2>
        <p>Scan this QR code or share the link below:</p>
        
        <div class="qr-code-container">
          <canvas id="qr-canvas" width="200" height="200"></canvas>
        </div>
        
        <div class="share-link">
          <label>Shareable Link:</label>
          <div class="link-container">
            <input type="text" id="share-link" value="${shareUrl}" readonly>
            <button id="copy-link" class="copy-btn">Copy</button>
          </div>
        </div>
        
        <div class="qr-actions">
          <button id="add-profile" class="add-profile-btn">Add Profile</button>
          <button id="download-qr" class="download-btn">Download QR</button>
          <button id="close-qr" class="close-btn">Close</button>
        </div>
      </div>
    </div>
  `;
  
  // Generate QR code
  generateQRCode(shareUrl);
  
  // Add event listeners
  document.getElementById('copy-link').onclick = () => {
    const linkInput = document.getElementById('share-link');
    linkInput.select();
    document.execCommand('copy');
    alert('Link copied to clipboard!');
  };
  
  document.getElementById('download-qr').onclick = () => {
    const canvas = document.getElementById('qr-canvas');
    const link = document.createElement('a');
    link.download = `${profile.name || 'profile'}_qr_code.png`;
    link.href = canvas.toDataURL();
    link.click();
  };
  
  document.getElementById('add-profile').onclick = () => {
    // Create a new profile with the shared data
    createProfileFromData(profile);
  };
  
  document.getElementById('close-qr').onclick = () => {
    showAdmin();
  };
}

function generateQRCode(text) {
  const canvas = document.getElementById('qr-canvas');
  const ctx = canvas.getContext('2d');
  
  // Simple QR code generation (using a basic pattern)
  // In a real app, you'd use a QR code library like qrcode.js
  const size = 200;
  const moduleSize = 4;
  const modules = size / moduleSize;
  
  // Clear canvas
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, size, size);
  
  // Draw QR pattern (simplified)
  ctx.fillStyle = '#000000';
  for (let i = 0; i < modules; i++) {
    for (let j = 0; j < modules; j++) {
      // Create a pattern based on text hash
      const hash = (i * 7 + j * 11 + text.length) % 3;
      if (hash === 0) {
        ctx.fillRect(i * moduleSize, j * moduleSize, moduleSize, moduleSize);
      }
    }
  }
  
  // Add corner markers
  const markerSize = 7;
  ctx.fillStyle = '#000000';
  // Top-left
  ctx.fillRect(0, 0, markerSize * moduleSize, markerSize * moduleSize);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(moduleSize, moduleSize, 5 * moduleSize, 5 * moduleSize);
  ctx.fillStyle = '#000000';
  ctx.fillRect(2 * moduleSize, 2 * moduleSize, 3 * moduleSize, 3 * moduleSize);
  
  // Top-right
  ctx.fillStyle = '#000000';
  ctx.fillRect((modules - markerSize) * moduleSize, 0, markerSize * moduleSize, markerSize * moduleSize);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect((modules - 6) * moduleSize, moduleSize, 5 * moduleSize, 5 * moduleSize);
  ctx.fillStyle = '#000000';
  ctx.fillRect((modules - 5) * moduleSize, 2 * moduleSize, 3 * moduleSize, 3 * moduleSize);
  
  // Bottom-left
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, (modules - markerSize) * moduleSize, markerSize * moduleSize, markerSize * moduleSize);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(moduleSize, (modules - 6) * moduleSize, 5 * moduleSize, 5 * moduleSize);
  ctx.fillStyle = '#000000';
  ctx.fillRect(2 * moduleSize, (modules - 5) * moduleSize, 3 * moduleSize, 3 * moduleSize);
}